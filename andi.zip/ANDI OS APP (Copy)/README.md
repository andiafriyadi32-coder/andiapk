# ANDI OS

Kokpit personal harian — offline, single-user, berbasis localStorage.

Stack: React 18 + TypeScript + Vite + Tailwind CSS + Capacitor (Android APK).

## Prasyarat

- Node.js 18 atau lebih baru
- npm 9 atau lebih baru
- Untuk build APK: Android Studio (desktop) atau Android Code Studio (mobile)

## Development

```bash
npm install
npm run dev