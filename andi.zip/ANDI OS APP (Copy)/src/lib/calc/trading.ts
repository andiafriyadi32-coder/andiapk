import type { Trade } from '../types';

export function tradeR(t: Trade): number | null {
  if (t.entry == null || t.sl == null) return null;
  const risk = Math.abs(t.entry - t.sl) * t.lot * 100_000;
  if (risk <= 0) return null;
  return Math.round((t.pl / risk) * 100) / 100;
}

export interface TradeStats {
  totalPl: number;
  wins: number;
  losses: number;
  bes: number;
  winRate: number;
  profitFactor: number | null;
  avgRR: number | null;
  expectancy: number;
  maxDrawdown: number;
  cumulativeR: number[];
}

export function tradeStats(trades: Trade[]): TradeStats {
  const wins = trades.filter((t) => t.result === 'profit');
  const losses = trades.filter((t) => t.result === 'loss');
  const bes = trades.filter((t) => t.result === 'be');

  const totalPl = trades.reduce((s, t) => s + t.pl, 0);

  const decisive = wins.length + losses.length;
  const winRate = decisive > 0 ? (wins.length / decisive) * 100 : 0;

  const grossProfit = wins.reduce((s, t) => s + Math.abs(t.pl), 0);
  const grossLoss = losses.reduce((s, t) => s + Math.abs(t.pl), 0);
  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : null;

  const winRs = wins.map((t) => t.r).filter((r): r is number => r != null);
  const lossRs = losses.map((t) => t.r).filter((r): r is number => r != null);

  const avgWinR = winRs.length ? winRs.reduce((s, r) => s + r, 0) / winRs.length : 0;
  const avgLossR = lossRs.length ? lossRs.reduce((s, r) => s + r, 0) / lossRs.length : 0;
  const avgRR = avgLossR !== 0 ? avgWinR / Math.abs(avgLossR) : null;

  const winRateDec = winRate / 100;
  const lossRateDec = decisive > 0 ? 1 - winRateDec : 0;
  const expectancy =
    decisive > 0 ? winRateDec * avgWinR - lossRateDec * Math.abs(avgLossR) : 0;

  const sorted = [...trades].sort(
    (a, b) => new Date(a.datetime).getTime() - new Date(b.datetime).getTime()
  );
  const cumulativeR: number[] = [];
  let cum = 0;
  let peak = 0;
  let maxDD = 0;
  for (const t of sorted) {
    const r = t.r ?? 0;
    cum += r;
    cumulativeR.push(cum);
    if (cum > peak) peak = cum;
    const dd = peak - cum;
    if (dd > maxDD) maxDD = dd;
  }

  return {
    totalPl,
    wins: wins.length,
    losses: losses.length,
    bes: bes.length,
    winRate,
    profitFactor,
    avgRR,
    expectancy,
    maxDrawdown: maxDD,
    cumulativeR,
  };
}

export function isRevengeTrade(t: Trade, all: Trade[]): boolean {
  if (t.result !== 'profit' && t.result !== 'loss' && t.result !== 'be') return false;
  const tTime = new Date(t.datetime).getTime();
  for (const prev of all) {
    if (prev.id === t.id) continue;
    if (prev.result !== 'loss') continue;
    const pTime = new Date(prev.datetime).getTime();
    const diff = tTime - pTime;
    if (diff > 0 && diff < 5 * 60 * 1000) return true;
  }
  return false;
}