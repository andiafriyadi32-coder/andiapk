import type { Budget, Transaction, Wallet } from '../types';
import { lastDayOfMonth, monthKey } from '../format';

export function walletBalance(w: Wallet, txs: Transaction[]): number {
  let bal = w.initial_balance;
  for (const t of txs) {
    if (t.type === 'income' && t.wallet_id === w.id) bal += t.amount;
    else if (t.type === 'expense' && t.wallet_id === w.id) bal -= t.amount;
    else if (t.type === 'transfer' && t.wallet_id === w.id) bal -= t.amount;
    else if (t.type === 'transfer' && t.to_wallet_id === w.id) bal += t.amount;
    else if (t.type === 'adjustment' && t.wallet_id === w.id) {
      if (t.sign === '+') bal += t.amount;
      else if (t.sign === '-') bal -= t.amount;
    }
  }
  return bal;
}

export function totalBalance(wallets: Wallet[], txs: Transaction[]): number {
  return wallets.reduce((sum, w) => sum + walletBalance(w, txs), 0);
}

export interface Cashflow {
  income: number;
  expense: number;
  net: number;
}

export function cashflow(
  txs: Transaction[],
  filterFn?: (t: Transaction) => boolean
): Cashflow {
  let income = 0;
  let expense = 0;
  for (const t of txs) {
    if (filterFn && !filterFn(t)) continue;
    if (t.type === 'income') income += t.amount;
    else if (t.type === 'expense') expense += t.amount;
  }
  return { income, expense, net: income - expense };
}

export interface CategorySlice {
  category: string;
  total: number;
  pct: number;
}

export function categoryBreakdown(
  txs: Transaction[],
  filterFn?: (t: Transaction) => boolean
): CategorySlice[] {
  const map = new Map<string, number>();
  let total = 0;
  for (const t of txs) {
    if (t.type !== 'expense') continue;
    if (filterFn && !filterFn(t)) continue;
    map.set(t.category, (map.get(t.category) ?? 0) + t.amount);
    total += t.amount;
  }
  const out: CategorySlice[] = [];
  for (const [category, amt] of map.entries()) {
    out.push({ category, total: amt, pct: total > 0 ? (amt / total) * 100 : 0 });
  }
  out.sort((a, b) => b.total - a.total);
  return out;
}

export interface SafeDailyBudget {
  budget: number;
  sisaHari: number;
  sisaUang: number;
  monthKey: string;
}

export function safeDailyBudget(txs: Transaction[], today: Date): SafeDailyBudget {
  const lastDay = lastDayOfMonth(today);
  const todayDate = today.getDate();
  const sisaHari = Math.max(1, lastDay - todayDate);
  const mk = monthKey(today);

  let income = 0;
  let expense = 0;
  for (const t of txs) {
    if (!t.date.startsWith(mk)) continue;
    if (t.type === 'income') income += t.amount;
    else if (t.type === 'expense') expense += t.amount;
  }
  const sisaUang = income - expense;
  const budget = Math.floor(sisaUang / sisaHari);
  return { budget, sisaHari, sisaUang, monthKey: mk };
}

export function safeToSpendToday(txs: Transaction[], today: Date): number {
  const { budget } = safeDailyBudget(txs, today);
  const todayStr_ = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  let todayExpense = 0;
  for (const t of txs) {
    if (t.type === 'expense' && t.date === todayStr_) todayExpense += t.amount;
  }
  return budget - todayExpense;
}

export interface ZeroBasedItem {
  budget: Budget;
  spent: number;
  remaining: number;
  progress: number;
  overspent: boolean;
}

export interface ZeroBasedResult {
  toBeBudgeted: number;
  totalBudget: number;
  items: ZeroBasedItem[];
}

export function zeroBasedBudget(
  txs: Transaction[],
  budgets: Budget[],
  monthKeyStr: string
): ZeroBasedResult {
  let income = 0;
  for (const t of txs) {
    if (t.type === 'income' && t.date.startsWith(monthKeyStr)) income += t.amount;
  }
  const monthly = budgets.filter((b) => b.period === 'monthly');
  const totalBudget = monthly.reduce((s, b) => s + b.amount, 0);
  const items: ZeroBasedItem[] = monthly.map((b) => {
    let spent = 0;
    for (const t of txs) {
      if (t.type === 'expense' && t.category === b.category && t.date.startsWith(monthKeyStr)) {
        spent += t.amount;
      }
    }
    const remaining = b.amount - spent;
    const progress = b.amount > 0 ? spent / b.amount : 0;
    return { budget: b, spent, remaining, progress, overspent: remaining < 0 };
  });
  return { toBeBudgeted: income - totalBudget, totalBudget, items };
}