import {
  createContext,
  useContext,
  useEffect,
  useReducer,
  type Dispatch,
  type ReactNode,
} from 'react';

import type {
  AppState,
  Budget,
  Debt,
  Habit,
  HabitLog,
  Journal,
  Note,
  PomodoroSession,
  SavingsGoal,
  Settings,
  Shift,
  SleepLog,
  Task,
  Trade,
  Transaction,
  Wallet,
} from './types';
import { uid } from './format';

const STORAGE_KEY = 'andi-os-v1';

/* ═══════════════════ TOAST BUS ═══════════════════ */

type ToastListener = (message: string) => void;
const toastListeners = new Set<ToastListener>();

export function emitToast(message: string): void {
  toastListeners.forEach((fn) => fn(message));
}

export function subscribeToast(fn: ToastListener): () => void {
  toastListeners.add(fn);
  return () => {
    toastListeners.delete(fn);
  };
}

/* ═══════════════════ ACTIONS ═══════════════════ */

export type Action =
  | { type: 'settings:update'; patch: Partial<Settings> }
  | { type: 'wallet:update'; id: string; patch: Partial<Pick<Wallet, 'name' | 'initial_balance'>> }
  | { type: 'transaction:add'; tx: Transaction }
  | { type: 'transaction:update'; id: string; patch: Partial<Transaction> }
  | { type: 'transaction:delete'; id: string }
  | { type: 'budget:add'; budget: Budget }
  | { type: 'budget:update'; id: string; patch: Partial<Budget> }
  | { type: 'budget:delete'; id: string }
  | { type: 'goal:add'; goal: SavingsGoal }
  | { type: 'goal:update'; id: string; patch: Partial<SavingsGoal> }
  | { type: 'goal:delete'; id: string }
  | { type: 'debt:add'; debt: Debt }
  | { type: 'debt:update'; id: string; patch: Partial<Debt> }
  | { type: 'debt:delete'; id: string }
  | { type: 'task:add'; task: Task }
  | { type: 'task:update'; id: string; patch: Partial<Task> }
  | { type: 'task:delete'; id: string }
  | { type: 'habit:add'; habit: Habit }
  | { type: 'habit:update'; id: string; patch: Partial<Habit> }
  | { type: 'habit:delete'; id: string }
  | { type: 'habitLog:toggle'; habitId: string; date: string }
  | { type: 'note:add'; note: Note }
  | { type: 'note:update'; id: string; patch: Partial<Note> }
  | { type: 'note:delete'; id: string }
  | { type: 'journal:add'; journal: Journal }
  | { type: 'journal:update'; id: string; patch: Partial<Journal> }
  | { type: 'journal:delete'; id: string }
  | { type: 'shift:add'; shift: Shift }
  | { type: 'shift:update'; id: string; patch: Partial<Shift> }
  | { type: 'shift:delete'; id: string }
  | { type: 'sleep:add'; log: SleepLog }
  | { type: 'sleep:update'; id: string; patch: Partial<SleepLog> }
  | { type: 'sleep:delete'; id: string }
  | { type: 'trade:add'; trade: Trade }
  | { type: 'trade:update'; id: string; patch: Partial<Trade> }
  | { type: 'trade:delete'; id: string }
  | { type: 'pomodoro:add'; session: PomodoroSession };

/* ═══════════════════ SEED INLINE ═══════════════════ */

function seedWallets(): Wallet[] {
  return [
    { id: 'w-tunai', name: 'TUNAI', type: 'cash', initial_balance: 0, sort_order: 0 },
    { id: 'w-dana', name: 'DANA', type: 'ewallet', initial_balance: 0, sort_order: 1 },
    { id: 'w-bank', name: 'BANK', type: 'bank', initial_balance: 0, sort_order: 2 },
  ];
}

function seedHabits(): Habit[] {
  const now = new Date().toISOString();
  return [
    { id: 'h-js', name: 'Belajar JS 30 menit', color: 'var(--accent-500)', frequency: 'daily', created_at: now },
    { id: 'h-air', name: 'Minum air 2L', color: 'var(--info)', frequency: 'daily', created_at: now },
    { id: 'h-tidur', name: 'Tidur 8 jam', color: 'var(--accent-300)', frequency: 'daily', created_at: now },
    { id: 'h-catat', name: 'Catat keuangan', color: 'var(--success)', frequency: 'daily', created_at: now },
  ];
}

/* ═══════════════════ INITIAL STATE ═══════════════════ */

function createInitialState(): AppState {
  return {
    version: 1,
    settings: {
      nama: 'Andi',
      theme: 'dark',
      active_modules: [
        'beranda', 'keuangan', 'tugas', 'kebiasaan', 'catatan', 'jurnal', 'pengaturan',
      ],
      currency: 'IDR',
      daily_water_target_ml: 2000,
      pomodoro: {
        focus: 25,
        short: 5,
        long: 15,
        long_break_interval: 4,
        sound: true,
      },
      budget_method: 'safe_daily',
    },
    wallets: seedWallets(),
    transactions: [],
    budgets: [],
    savings_goals: [],
    debts: [],
    tasks: [],
    habits: seedHabits(),
    habit_logs: [],
    notes: [],
    journal: [],
    shifts: [],
    sleep_logs: [],
    trades: [],
    pomodoro_sessions: [],
  };
}

function loadState(): AppState {
  const base = createInitialState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return base;
    const parsed: unknown = JSON.parse(raw);
    if (
      typeof parsed !== 'object' ||
      parsed === null ||
      (parsed as { version?: unknown }).version !== 1
    ) {
      return base;
    }
    const p = parsed as Partial<AppState>;
    return {
      ...base,
      ...p,
      settings: {
        ...base.settings,
        ...(p.settings ?? {}),
        pomodoro: {
          ...base.settings.pomodoro,
          ...(p.settings?.pomodoro ?? {}),
        },
      },
    };
  } catch {
    return base;
  }
}

/* ═══════════════════ HELPER REDUCER ═══════════════════ */

function patchById<T extends { id: string }>(arr: T[], id: string, patch: Partial<T>): T[] {
  return arr.map((x) => (x.id === id ? { ...x, ...patch } : x));
}

function removeById<T extends { id: string }>(arr: T[], id: string): T[] {
  return arr.filter((x) => x.id !== id);
}

/* ═══════════════════ REDUCER ═══════════════════ */

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'settings:update':
      return {
        ...state,
        settings: {
          ...state.settings,
          ...action.patch,
          pomodoro: { ...state.settings.pomodoro, ...(action.patch.pomodoro ?? {}) },
        },
      };

    case 'wallet:update':
      return { ...state, wallets: patchById(state.wallets, action.id, action.patch) };

    case 'transaction:add':
      return { ...state, transactions: [action.tx, ...state.transactions] };
    case 'transaction:update':
      return { ...state, transactions: patchById(state.transactions, action.id, action.patch) };
    case 'transaction:delete':
      return { ...state, transactions: removeById(state.transactions, action.id) };

    case 'budget:add':
      return { ...state, budgets: [...state.budgets, action.budget] };
    case 'budget:update':
      return { ...state, budgets: patchById(state.budgets, action.id, action.patch) };
    case 'budget:delete':
      return { ...state, budgets: removeById(state.budgets, action.id) };

    case 'goal:add':
      return { ...state, savings_goals: [...state.savings_goals, action.goal] };
    case 'goal:update':
      return { ...state, savings_goals: patchById(state.savings_goals, action.id, action.patch) };
    case 'goal:delete':
      return { ...state, savings_goals: removeById(state.savings_goals, action.id) };

    case 'debt:add':
      return { ...state, debts: [...state.debts, action.debt] };
    case 'debt:update':
      return { ...state, debts: patchById(state.debts, action.id, action.patch) };
    case 'debt:delete':
      return { ...state, debts: removeById(state.debts, action.id) };

    case 'task:add':
      return { ...state, tasks: [action.task, ...state.tasks] };
    case 'task:update':
      return { ...state, tasks: patchById(state.tasks, action.id, action.patch) };
    case 'task:delete':
      return { ...state, tasks: removeById(state.tasks, action.id) };

    case 'habit:add':
      return { ...state, habits: [...state.habits, action.habit] };
    case 'habit:update':
      return { ...state, habits: patchById(state.habits, action.id, action.patch) };
    case 'habit:delete':
      return {
        ...state,
        habits: removeById(state.habits, action.id),
        habit_logs: state.habit_logs.filter((l) => l.habit_id !== action.id),
      };

    case 'habitLog:toggle': {
      const existing = state.habit_logs.find(
        (l) => l.habit_id === action.habitId && l.date === action.date
      );
      if (existing) {
        return { ...state, habit_logs: removeById(state.habit_logs, existing.id) };
      }
      const newLog: HabitLog = {
        id: uid(),
        habit_id: action.habitId,
        date: action.date,
        created_at: new Date().toISOString(),
      };
      return { ...state, habit_logs: [...state.habit_logs, newLog] };
    }

    case 'note:add':
      return { ...state, notes: [action.note, ...state.notes] };
    case 'note:update':
      return { ...state, notes: patchById(state.notes, action.id, action.patch) };
    case 'note:delete':
      return { ...state, notes: removeById(state.notes, action.id) };

    case 'journal:add':
      return { ...state, journal: [action.journal, ...state.journal] };
    case 'journal:update':
      return { ...state, journal: patchById(state.journal, action.id, action.patch) };
    case 'journal:delete':
      return { ...state, journal: removeById(state.journal, action.id) };

    case 'shift:add':
      return { ...state, shifts: [...state.shifts, action.shift] };
    case 'shift:update':
      return { ...state, shifts: patchById(state.shifts, action.id, action.patch) };
    case 'shift:delete':
      return { ...state, shifts: removeById(state.shifts, action.id) };

    case 'sleep:add':
      return { ...state, sleep_logs: [action.log, ...state.sleep_logs] };
    case 'sleep:update':
      return { ...state, sleep_logs: patchById(state.sleep_logs, action.id, action.patch) };
    case 'sleep:delete':
      return { ...state, sleep_logs: removeById(state.sleep_logs, action.id) };

    case 'trade:add':
      return { ...state, trades: [action.trade, ...state.trades] };
    case 'trade:update':
      return { ...state, trades: patchById(state.trades, action.id, action.patch) };
    case 'trade:delete':
      return { ...state, trades: removeById(state.trades, action.id) };

    case 'pomodoro:add':
      return { ...state, pomodoro_sessions: [action.session, ...state.pomodoro_sessions] };

    default: {
      const _exhaustive: never = action;
      void _exhaustive;
      return state;
    }
  }
}

/* ═══════════════════ CONTEXT ═══════════════════ */

interface StoreValue {
  state: AppState;
  dispatch: Dispatch<Action>;
}

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }): JSX.Element {
  const [state, dispatch] = useReducer(reducer, undefined, loadState);

  useEffect(() => {
    const handle = window.setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      } catch (err) {
        if (
          err instanceof DOMException &&
          (err.name === 'QuotaExceededError' || err.code === 22)
        ) {
          emitToast('Penyimpanan penuh. Ekspor data lalu reset di Pengaturan.');
        } else {
          emitToast('Gagal menyimpan data. Coba lagi.');
        }
      }
    }, 300);
    return () => window.clearTimeout(handle);
  }, [state]);

  useEffect(() => {
    const dark = state.settings.theme === 'dark';
    document.documentElement.classList.toggle('dark', dark);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) {
      meta.setAttribute('content', dark ? '#0A0E1A' : '#F5F1FB');
    }
  }, [state.settings.theme]);

  return <StoreContext.Provider value={{ state, dispatch }}>{children}</StoreContext.Provider>;
}

/* ═══════════════════ HOOKS ═══════════════════ */

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) {
    throw new Error('useStore harus dipakai di dalam StoreProvider');
  }
  return ctx;
}

export function useAppState(): AppState {
  return useStore().state;
}

export function useDispatch(): Dispatch<Action> {
  return useStore().dispatch;
}

export function useModuleEnabled(moduleId: string): boolean {
  const { state } = useStore();
  return state.settings.active_modules.includes(
    moduleId as AppState['settings']['active_modules'][number]
  );
}