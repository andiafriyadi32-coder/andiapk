export interface SkeletonProps {
  className?: string;
  width?: string | number;
  height?: string | number;
  rounded?: string;
}

export function Skeleton({
  className = '',
  width,
  height,
  rounded = 'rounded-md',
}: SkeletonProps) {
  return (
    <div
      className={`animate-pulse bg-surface-4 ${rounded} ${className}`}
      style={{ width, height }}
      aria-hidden
    />
  );
}