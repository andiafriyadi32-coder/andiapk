import { forwardRef, useId, type SelectHTMLAttributes } from 'react';

export interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(function Select(
  { label, error, hint, id, className = '', children, ...rest },
  ref
) {
  const autoId = useId();
  const selId = id ?? autoId;
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={selId} className="text-label text-fg-mid">
          {label}
        </label>
      )}
      <div className="relative">
        <select
          ref={ref}
          id={selId}
          className={`h-11 w-full appearance-none rounded-input border bg-surface-2 px-3.5 pr-10 text-body text-fg-hi transition-colors duration-standard ease-standard focus:border-accent-500 focus:outline-none focus:ring-1 focus:ring-accent-500 ${
            error ? 'border-danger' : 'border-line'
          } ${className}`}
          {...rest}
        >
          {children}
        </select>
        <svg
          className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg-lo"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          aria-hidden
        >
          <path d="M6 9l6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      {error ? (
        <span className="text-caption text-danger">{error}</span>
      ) : hint ? (
        <span className="text-caption text-fg-lo">{hint}</span>
      ) : null}
    </div>
  );
});