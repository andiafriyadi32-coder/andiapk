import type { ButtonHTMLAttributes } from 'react';

export type ChipTone = 'neutral' | 'accent' | 'success' | 'warning' | 'danger';

export interface ChipProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  active?: boolean;
  tone?: ChipTone;
}

export function Chip({
  active = false,
  tone = 'neutral',
  type = 'button',
  className = '',
  children,
  ...rest
}: ChipProps) {
  const toneCls = active
    ? 'bg-accent-500 text-white border-accent-500'
    : tone === 'danger'
      ? 'bg-surface-2 text-danger border-line'
      : tone === 'success'
        ? 'bg-surface-2 text-success border-line'
        : tone === 'warning'
          ? 'bg-surface-2 text-warning border-line'
          : tone === 'accent'
            ? 'bg-surface-2 text-accent-500 border-line'
            : 'bg-surface-2 text-fg-mid border-line';
  return (
    <button
      type={type}
      className={`inline-flex h-8 items-center gap-1.5 rounded-chip border px-3 text-caption font-medium transition-colors duration-standard ease-standard hover:border-line-strong ${toneCls} ${className}`}
      aria-pressed={active}
      {...rest}
    >
      {children}
    </button>
  );
}