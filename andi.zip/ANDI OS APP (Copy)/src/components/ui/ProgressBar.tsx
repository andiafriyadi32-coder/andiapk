export type ProgressTone = 'accent' | 'success' | 'warning' | 'danger';

export interface ProgressBarProps {
  value: number;
  tone?: ProgressTone;
  height?: number;
  className?: string;
}

export function ProgressBar({
  value,
  tone = 'accent',
  height = 6,
  className = '',
}: ProgressBarProps) {
  const clamped = Math.max(0, Math.min(1, value));
  const pct = clamped * 100;
  const fill =
    tone === 'danger'
      ? 'bg-danger'
      : tone === 'warning'
        ? 'bg-warning'
        : tone === 'success'
          ? 'bg-success'
          : 'bg-accent-500';
  return (
    <div
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(pct)}
      className={`w-full overflow-hidden rounded-full bg-surface-4 ${className}`}
      style={{ height }}
    >
      <div
        className={`h-full ${fill} transition-[width] duration-slow ease-emphasized`}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}