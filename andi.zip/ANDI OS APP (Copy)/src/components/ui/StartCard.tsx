import type { ReactNode } from 'react';

export type StatTone = 'default' | 'accent' | 'success' | 'danger' | 'warning';

export interface StatCardProps {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  tone?: StatTone;
  className?: string;
}

export function StatCard({
  label,
  value,
  hint,
  tone = 'default',
  className = '',
}: StatCardProps) {
  const toneCls =
    tone === 'accent'
      ? 'text-accent-500'
      : tone === 'success'
        ? 'text-success'
        : tone === 'danger'
          ? 'text-danger'
          : tone === 'warning'
            ? 'text-warning'
            : 'text-fg-hi';
  return (
    <div className={`rounded-card-sm border border-line bg-surface-2 p-4 ${className}`}>
      <p className="text-micro uppercase text-fg-lo">{label}</p>
      <p className={`num mt-1.5 text-stat-num ${toneCls}`}>{value}</p>
      {hint && <p className="mt-1 text-caption text-fg-lo">{hint}</p>}
    </div>
  );
}