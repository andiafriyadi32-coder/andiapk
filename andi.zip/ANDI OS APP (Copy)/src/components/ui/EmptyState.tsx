import type { ReactNode } from 'react';

export interface EmptyStateProps {
  icon: ReactNode;
  title: string;
  description: string;
  action?: ReactNode;
}

export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-card border border-dashed border-line bg-surface-2 px-6 py-12 text-center">
      <div className="text-accent-300">{icon}</div>
      <h3 className="text-h2 text-fg-hi">{title}</h3>
      <p className="max-w-xs text-body text-fg-mid">{description}</p>
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}