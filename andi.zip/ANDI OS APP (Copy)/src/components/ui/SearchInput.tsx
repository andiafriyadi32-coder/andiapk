import { useEffect, useState } from 'react';
import { Search, X } from 'lucide-react';

export interface SearchInputProps {
  value: string;
  onChange: (next: string) => void;
  placeholder?: string;
  delay?: number;
}

export function SearchInput({
  value,
  onChange,
  placeholder = 'Cari…',
  delay = 300,
}: SearchInputProps) {
  const [local, setLocal] = useState(value);

  useEffect(() => {
    setLocal(value);
  }, [value]);

  useEffect(() => {
    const handle = window.setTimeout(() => onChange(local), delay);
    return () => window.clearTimeout(handle);
  }, [local, delay, onChange]);

  return (
    <div className="relative">
      <Search
        className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg-lo"
        aria-hidden
      />
      <input
        value={local}
        onChange={(e) => setLocal(e.target.value)}
        placeholder={placeholder}
        className="h-11 w-full rounded-input border border-line bg-surface-2 pl-9 pr-9 text-body text-fg-hi placeholder:text-fg-dim transition-colors duration-standard ease-standard focus:border-accent-500 focus:outline-none focus:ring-1 focus:ring-accent-500"
      />
      {local && (
        <button
          type="button"
          onClick={() => {
            setLocal('');
            onChange('');
          }}
          className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-fg-lo hover:text-fg-hi"
          aria-label="Hapus pencarian"
        >
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}