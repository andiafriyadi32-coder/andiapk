import { forwardRef, useId, type InputHTMLAttributes } from 'react';

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { label, error, hint, id, className = '', ...rest },
  ref
) {
  const autoId = useId();
  const inputId = id ?? autoId;
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={inputId} className="text-label text-fg-mid">
          {label}
        </label>
      )}
      <input
        ref={ref}
        id={inputId}
        className={`h-11 rounded-input border bg-surface-2 px-3.5 text-body text-fg-hi placeholder:text-fg-dim transition-colors duration-standard ease-standard focus:border-accent-500 focus:outline-none focus:ring-1 focus:ring-accent-500 ${
          error ? 'border-danger' : 'border-line'
        } ${className}`}
        {...rest}
      />
      {error ? (
        <span className="text-caption text-danger">{error}</span>
      ) : hint ? (
        <span className="text-caption text-fg-lo">{hint}</span>
      ) : null}
    </div>
  );
});