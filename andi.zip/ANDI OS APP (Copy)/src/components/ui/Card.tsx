import type { ReactNode } from 'react';

export interface CardProps {
  children: ReactNode;
  className?: string;
  padded?: boolean;
}

export function Card({ children, className = '', padded = true }: CardProps) {
  return (
    <div
      className={`rounded-card border border-line bg-surface-2 ${
        padded ? 'p-5' : ''
      } ${className}`}
    >
      {children}
    </div>
  );
}