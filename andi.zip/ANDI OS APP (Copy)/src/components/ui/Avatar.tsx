export interface AvatarProps {
  name: string;
  size?: number;
}

export function Avatar({ name, size = 40 }: AvatarProps) {
  const trimmed = name.trim();
  const initial = (trimmed.length > 0 ? trimmed[0] : '?') ?? '?';
  return (
    <div
      className="flex items-center justify-center rounded-full bg-deep-hero text-white"
      style={{
        width: size,
        height: size,
        fontSize: Math.round(size * 0.42),
        fontWeight: 600,
      }}
      aria-hidden
    >
      {initial.toUpperCase()}
    </div>
  );
}