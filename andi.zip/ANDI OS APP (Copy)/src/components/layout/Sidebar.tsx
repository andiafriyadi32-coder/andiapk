import {
  BookOpen, CheckSquare, Clock, FileText, Home, Moon,
  Repeat, Settings, Timer, TrendingUp, Wallet, type LucideIcon,
} from 'lucide-react';

import { MODULE_LABELS, type ModuleId } from '../../lib/types';

interface SidebarNavItem {
  id: ModuleId;
  icon: LucideIcon;
}

const NAV_ALL: SidebarNavItem[] = [
  { id: 'beranda', icon: Home },
  { id: 'keuangan', icon: Wallet },
  { id: 'tugas', icon: CheckSquare },
  { id: 'kebiasaan', icon: Repeat },
  { id: 'catatan', icon: FileText },
  { id: 'jurnal', icon: BookOpen },
  { id: 'shift', icon: Clock },
  { id: 'tidur', icon: Moon },
  { id: 'trading', icon: TrendingUp },
  { id: 'fokus', icon: Timer },
  { id: 'pengaturan', icon: Settings },
];

export interface SidebarProps {
  module: ModuleId;
  enabled: ModuleId[];
  onNavigate: (m: ModuleId) => void;
}

export function Sidebar({ module, enabled, onNavigate }: SidebarProps) {
  const items = NAV_ALL.filter((i) => enabled.includes(i.id));
  return (
    <aside className="hidden w-60 shrink-0 flex-col border-r border-line bg-deep-sidebar p-5 lg:flex">
      <div className="mb-8 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-button bg-white/10 text-white">
          <span className="text-h2 font-bold">A</span>
        </div>
        <div className="min-w-0">
          <p className="truncate text-h2 text-white">ANDI OS</p>
          <p className="text-caption text-white/50">Kokpit harian</p>
        </div>
      </div>
      <nav className="flex flex-col gap-1">
        {items.map((item) => {
          const Icon = item.icon;
          const active = module === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`flex items-center gap-3 rounded-button px-3 py-2.5 text-label transition-colors duration-standard ease-standard ${
                active
                  ? 'bg-white/10 text-white'
                  : 'text-white/60 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Icon className="h-5 w-5" strokeWidth={1.75} />
              {MODULE_LABELS[item.id]}
            </button>
          );
        })}
      </nav>
    </aside>
  );
}