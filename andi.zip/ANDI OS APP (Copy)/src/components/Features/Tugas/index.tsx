import { useMemo, useState } from 'react';
import { Archive, CheckSquare, Plus, RotateCcw, Trash2 } from 'lucide-react';

import { useAppState, useDispatch } from '../../lib/store';
import {
  TASK_CATEGORY_LABELS, type Subtask, type Task, type TaskCategory,
  type TaskPriority, type TaskStatus,
} from '../../lib/types';
import { formatDateShort, todayStr, uid } from '../../lib/format';
import { Button } from '../../components/ui/Button';
import { Chip } from '../../components/ui/Chip';
import { Checkbox } from '../../components/ui/Checkbox';
import { Input } from '../../components/ui/Input';
import { SegmentedControl, type SegmentedOption } from '../../components/ui/SegmentedControl';
import { Select } from '../../components/ui/Select';
import { Textarea } from '../../components/ui/Textarea';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';

type View = 'list' | 'kanban' | 'arsip';
type Filter = 'semua' | 'belum' | 'selesai';

const VIEW_OPTIONS: SegmentedOption<View>[] = [
  { value: 'list', label: 'Daftar' },
  { value: 'kanban', label: 'Kanban' },
  { value: 'arsip', label: 'Arsip' },
];

const CATEGORY_COLORS: Record<TaskCategory, string> = {
  rs: 'bg-info/15 text-info',
  koding: 'bg-accent-100 text-accent-500',
  pribadi: 'bg-warning/15 text-warning',
  lainnya: 'bg-surface-4 text-fg-mid',
};

export default function Tugas(): JSX.Element {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const [view, setView] = useState<View>('list');
  const [filter, setFilter] = useState<Filter>('semua');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [deleting, setDeleting] = useState<Task | null>(null);

  const active = useMemo(
    () => state.tasks.filter((t) => t.status !== 'archived'),
    [state.tasks]
  );
  const archived = useMemo(
    () => state.tasks.filter((t) => t.status === 'archived'),
    [state.tasks]
  );

  const counts = {
    semua: active.length,
    belum: active.filter((t) => t.status === 'todo').length,
    selesai: active.filter((t) => t.status === 'done').length,
  };

  const visible = useMemo(() => {
    const list = filter === 'belum'
      ? active.filter((t) => t.status === 'todo')
      : filter === 'selesai'
        ? active.filter((t) => t.status === 'done')
        : active;
    return [...list].sort((a, b) => {
      const r = { high: 0, medium: 1, low: 2 } as Record<TaskPriority, number>;
      const pri = r[a.priority] - r[b.priority];
      if (pri !== 0) return pri;
      return (a.due_date ?? '9999').localeCompare(b.due_date ?? '9999');
    });
  }, [active, filter]);

  function toggleDone(t: Task) {
    const next: TaskStatus = t.status === 'done' ? 'todo' : 'done';
    dispatch({
      type: 'task:update',
      id: t.id,
      patch: { status: next, updated_at: new Date().toISOString() },
    });
    if (next === 'done') show('Tugas selesai.');
  }

  function archiveTask(t: Task) {
    dispatch({
      type: 'task:update',
      id: t.id,
      patch: { status: 'archived', updated_at: new Date().toISOString() },
    });
    show('Tugas diarsipkan.');
  }

  function restoreTask(t: Task) {
    dispatch({
      type: 'task:update',
      id: t.id,
      patch: { status: 'todo', updated_at: new Date().toISOString() },
    });
    show('Tugas dikembalikan.');
  }

  function openCreate() {
    setEditing(null);
    setFormOpen(true);
  }

  function openEdit(t: Task) {
    setEditing(t);
    setFormOpen(true);
  }

  function confirmDelete() {
    if (!deleting) return;
    const snapshot = deleting;
    dispatch({ type: 'task:delete', id: snapshot.id });
    setDeleting(null);
    show('Tugas dihapus.', {
      action: {
        label: 'Urungkan',
        onClick: () => dispatch({ type: 'task:add', task: snapshot }),
      },
      duration: 5000,
    });
  }

  return (
    <div className="flex flex-col gap-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-micro uppercase text-fg-lo">Tugas</p>
          <h1 className="text-h1 text-fg-hi">Satu hal pada satu waktu.</h1>
        </div>
        <Button onClick={openCreate} icon={<Plus className="h-4 w-4" strokeWidth={2} />}>
          Tugas
        </Button>
      </header>

      <SegmentedControl options={VIEW_OPTIONS} value={view} onChange={setView} />

      {view === 'list' && (
        <>
          <div className="flex flex-wrap gap-1.5">
            <Chip active={filter === 'semua'} onClick={() => setFilter('semua')}>
              Semua ({counts.semua})
            </Chip>
            <Chip active={filter === 'belum'} onClick={() => setFilter('belum')}>
              Belum ({counts.belum})
            </Chip>
            <Chip active={filter === 'selesai'} onClick={() => setFilter('selesai')}>
              Selesai ({counts.selesai})
            </Chip>
          </div>

          {visible.length === 0 ? (
            <EmptyState
              icon={<CheckSquare className="h-10 w-10" strokeWidth={1.5} />}
              title="Belum ada tugas."
              description="Mulai dari satu hal kecil hari ini."
              action={<Button onClick={openCreate}>Tugas pertama</Button>}
            />
          ) : (
            <ul className="flex flex-col gap-2">
              {visible.map((t) => (
                <TaskRow
                  key={t.id}
                  task={t}
                  onToggle={() => toggleDone(t)}
                  onEdit={() => openEdit(t)}
                  onArchive={() => archiveTask(t)}
                  onDelete={() => setDeleting(t)}
                />
              ))}
            </ul>
          )}
        </>
      )}

      {view === 'kanban' && (
        <KanbanView
          tasks={active}
          onToggle={toggleDone}
          onEdit={openEdit}
        />
      )}

      {view === 'arsip' && (
        <>
          {archived.length === 0 ? (
            <EmptyState
              icon={<Archive className="h-10 w-10" strokeWidth={1.5} />}
              title="Arsip kosong."
              description="Tugas yang diarsipkan akan muncul di sini."
            />
          ) : (
            <ul className="flex flex-col gap-2">
              {archived.map((t) => (
                <Card key={t.id}>
                  <div className="flex items-center gap-2">
                    <p className="min-w-0 flex-1 truncate text-body text-fg-hi">{t.title}</p>
                    <Button size="sm" variant="ghost" onClick={() => restoreTask(t)} icon={<RotateCcw className="h-3.5 w-3.5" strokeWidth={2} />}>
                      Pulihkan
                    </Button>
                    <button
                      type="button"
                      onClick={() => setDeleting(t)}
                      className="rounded-button p-1.5 text-fg-lo hover:bg-surface-3 hover:text-danger"
                      aria-label="Hapus permanen"
                    >
                      <Trash2 className="h-4 w-4" strokeWidth={1.75} />
                    </button>
                  </div>
                </Card>
              ))}
            </ul>
          )}
        </>
      )}

      <TaskForm
        open={formOpen}
        onClose={() => { setFormOpen(false); setEditing(null); }}
        initial={editing}
      />

      <ConfirmDialog
        open={deleting !== null}
        title="Hapus tugas ini?"
        description={deleting ? `"${deleting.title}" akan dihapus.` : ''}
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}

function TaskRow({
  task, onToggle, onEdit, onArchive, onDelete,
}: {
  task: Task;
  onToggle: () => void;
  onEdit: () => void;
  onArchive: () => void;
  onDelete: () => void;
}) {
  const overdue = task.due_date && task.due_date < todayStr() && task.status === 'todo';
  const subProgress = task.subtasks && task.subtasks.length > 0
    ? `${task.subtasks.filter((s) => s.done).length}/${task.subtasks.length}`
    : null;
  return (
    <li>
      <Card padded={false}>
        <div className="flex items-start gap-3 p-3">
          <Checkbox checked={task.status === 'done'} onChange={onToggle} ariaLabel="Tandai selesai" />
          <button type="button" onClick={onEdit} className="min-w-0 flex-1 text-left">
            <p className={`truncate text-body ${task.status === 'done' ? 'line-through text-fg-lo' : 'text-fg-hi'}`}>
              {task.title}
            </p>
            <div className="mt-1 flex flex-wrap items-center gap-1.5">
              <span className={`rounded-chip px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${CATEGORY_COLORS[task.category]}`}>
                {TASK_CATEGORY_LABELS[task.category]}
              </span>
              {task.due_date && (
                <span className={`text-caption ${overdue ? 'text-danger' : 'text-fg-lo'}`}>
                  {overdue ? 'Terlambat · ' : ''}{formatDateShort(new Date(task.due_date))}
                </span>
              )}
              {subProgress && <span className="text-caption text-fg-lo">{subProgress} subtugas</span>}
            </div>
          </button>
          <div className="flex shrink-0 items-center gap-1">
            <span
              className={`h-2 w-2 rounded-full ${
                task.priority === 'high' ? 'bg-danger' : task.priority === 'medium' ? 'bg-warning' : 'bg-fg-dim'
              }`}
              aria-label={`Prioritas ${task.priority}`}
            />
            <button type="button" onClick={onArchive} className="rounded-button p-1 text-fg-lo hover:text-fg-hi" aria-label="Arsipkan">
              <Archive className="h-4 w-4" strokeWidth={1.75} />
            </button>
            <button type="button" onClick={onDelete} className="rounded-button p-1 text-fg-lo hover:text-danger" aria-label="Hapus">
              <Trash2 className="h-4 w-4" strokeWidth={1.75} />
            </button>
          </div>
        </div>
      </Card>
    </li>
  );
}

function KanbanView({
  tasks, onToggle, onEdit,
}: {
  tasks: Task[];
  onToggle: (t: Task) => void;
  onEdit: (t: Task) => void;
}) {
  const todo = tasks.filter((t) => t.status === 'todo');
  const done = tasks.filter((t) => t.status === 'done');
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      <Card>
        <p className="mb-2 text-micro uppercase text-fg-lo">Todo ({todo.length})</p>
        {todo.length === 0 ? (
          <p className="py-4 text-center text-caption text-fg-lo">Kosong.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {todo.map((t) => (
              <li key={t.id}>
                <button
                  type="button"
                  onClick={() => onEdit(t)}
                  className="w-full rounded-card-sm border border-line bg-surface-2 p-3 text-left hover:border-line-strong"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-body text-fg-hi">{t.title}</p>
                    <span
                      className={`h-2 w-2 shrink-0 rounded-full ${
                        t.priority === 'high' ? 'bg-danger' : t.priority === 'medium' ? 'bg-warning' : 'bg-fg-dim'
                      }`}
                    />
                  </div>
                  <p className="mt-1 text-caption text-fg-lo">
                    {TASK_CATEGORY_LABELS[t.category]}{t.due_date ? ` · ${formatDateShort(new Date(t.due_date))}` : ''}
                  </p>
                </button>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Card>
        <p className="mb-2 text-micro uppercase text-fg-lo">Selesai ({done.length})</p>
        {done.length === 0 ? (
          <p className="py-4 text-center text-caption text-fg-lo">Kosong.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {done.map((t) => (
              <li key={t.id}>
                <div className="flex items-center gap-2 rounded-card-sm border border-line bg-surface-2 p-3">
                  <Checkbox checked onChange={() => onToggle(t)} ariaLabel="Batalkan" />
                  <p className="min-w-0 flex-1 truncate text-body text-fg-lo line-through">{t.title}</p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function TaskForm({
  open, onClose, initial,
}: {
  open: boolean;
  onClose: () => void;
  initial: Task | null;
}) {
  const dispatch = useDispatch();
  const { show } = useToast();
  const [title, setTitle] = useState(initial?.title ?? '');
  const [category, setCategory] = useState<TaskCategory>(initial?.category ?? 'pribadi');
  const [priority, setPriority] = useState<TaskPriority>(initial?.priority ?? 'medium');
  const [dueDate, setDueDate] = useState(initial?.due_date ?? '');
  const [notes, setNotes] = useState(initial?.notes ?? '');
  const [subtasks, setSubtasks] = useState<Subtask[]>(initial?.subtasks ?? []);
  const [subInput, setSubInput] = useState('');
  const [error, setError] = useState<string | null>(null);

  function addSub() {
    if (!subInput.trim()) return;
    setSubtasks((s) => [...s, { id: uid(), title: subInput.trim(), done: false }]);
    setSubInput('');
  }

  function submit() {
    if (!title.trim()) {
      setError('Judul tugas wajib diisi.');
      return;
    }
    const now = new Date().toISOString();
    const payload: Task = {
      id: initial?.id ?? uid(),
      title: title.trim(),
      category,
      priority,
      status: initial?.status ?? 'todo',
      due_date: dueDate || undefined,
      notes: notes || undefined,
      subtasks: subtasks.length > 0 ? subtasks : undefined,
      created_at: initial?.created_at ?? now,
      updated_at: now,
    };
    if (initial) {
      dispatch({ type: 'task:update', id: initial.id, patch: payload });
      show('Tugas diperbarui.');
    } else {
      dispatch({ type: 'task:add', task: payload });
      show('Tugas ditambahkan.');
    }
    setError(null);
    onClose();
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={initial ? 'Ubah tugas' : 'Tugas baru'}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>Batal</Button>
          <Button onClick={submit}>{initial ? 'Simpan' : 'Tambah'}</Button>
        </div>
      }
    >
      <div className="flex flex-col gap-3">
        <Input
          label="Judul"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          error={error ?? undefined}
          autoFocus
        />
        <Select
          label="Kategori"
          value={category}
          onChange={(e) => setCategory(e.target.value as TaskCategory)}
        >
          {(Object.keys(TASK_CATEGORY_LABELS) as TaskCategory[]).map((c) => (
            <option key={c} value={c}>{TASK_CATEGORY_LABELS[c]}</option>
          ))}
        </Select>
        <div>
          <p className="mb-1.5 text-label text-fg-mid">Prioritas</p>
          <div className="flex gap-1.5">
            <Chip active={priority === 'low'} onClick={() => setPriority('low')}>Rendah</Chip>
            <Chip active={priority === 'medium'} onClick={() => setPriority('medium')}>Sedang</Chip>
            <Chip active={priority === 'high'} onClick={() => setPriority('high')}>Tinggi</Chip>
          </div>
        </div>
        <Input
          label="Tenggat (opsional)"
          type="date"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
        />
        <Textarea
          label="Catatan"
          rows={2}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
        <div>
          <p className="mb-1.5 text-label text-fg-mid">Subtugas</p>
          <div className="flex gap-2">
            <div className="flex-1">
              <Input
                value={subInput}
                onChange={(e) => setSubInput(e.target.value)}
                placeholder="Tambah subtugas"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addSub();
                  }
                }}
              />
            </div>
            <Button variant="secondary" onClick={addSub} icon={<Plus className="h-4 w-4" strokeWidth={2} />}>
              Tambah
            </Button>
          </div>
          {subtasks.length > 0 && (
            <ul className="mt-2 flex flex-col gap-1">
              {subtasks.map((s) => (
                <li key={s.id} className="flex items-center gap-2 rounded-card-sm border border-line bg-surface-2 px-3 py-2">
                  <Checkbox
                    checked={s.done}
                    onChange={() =>
                      setSubtasks((prev) => prev.map((x) => x.id === s.id ? { ...x, done: !x.done } : x))
                    }
                    size="sm"
                    ariaLabel="Selesai"
                  />
                  <span className={`min-w-0 flex-1 truncate text-body ${s.done ? 'line-through text-fg-lo' : 'text-fg-hi'}`}>
                    {s.title}
                  </span>
                  <button
                    type="button"
                    onClick={() => setSubtasks((prev) => prev.filter((x) => x.id !== s.id))}
                    className="text-fg-lo hover:text-danger"
                    aria-label="Hapus subtugas"
                  >
                    <Trash2 className="h-3.5 w-3.5" strokeWidth={2} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </BottomSheet>
  );
}