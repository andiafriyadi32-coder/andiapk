import { useMemo, useState } from 'react';
import { FileText, Pin, Plus, Trash2 } from 'lucide-react';

import { useAppState, useDispatch } from '../../lib/store';
import type { Note } from '../../lib/types';
import { formatRelative, uid } from '../../lib/format';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { SearchInput } from '../../components/ui/SearchInput';
import { Textarea } from '../../components/ui/Textarea';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';

const NOTE_COLORS: { key: string; label: string; bar: string }[] = [
  { key: 'accent', label: 'Ungu', bar: 'bg-accent-500' },
  { key: 'success', label: 'Hijau', bar: 'bg-success' },
  { key: 'warning', label: 'Kuning', bar: 'bg-warning' },
  { key: 'danger', label: 'Merah', bar: 'bg-danger' },
  { key: 'info', label: 'Biru', bar: 'bg-info' },
  { key: 'neutral', label: 'Netral', bar: 'bg-fg-dim' },
];

function colorBar(key?: string): string {
  return NOTE_COLORS.find((c) => c.key === key)?.bar ?? 'bg-fg-dim';
}

export default function Catatan(): JSX.Element {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const [query, setQuery] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Note | null>(null);
  const [deleting, setDeleting] = useState<Note | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q
      ? state.notes.filter(
          (n) =>
            n.title.toLowerCase().includes(q) ||
            n.content.toLowerCase().includes(q) ||
            (n.tags ?? []).some((t) => t.toLowerCase().includes(q))
        )
      : state.notes;
    return [...list].sort((a, b) => {
      if (!!b.pinned !== !!a.pinned) return b.pinned ? 1 : -1;
      return b.updated_at.localeCompare(a.updated_at);
    });
  }, [state.notes, query]);

  function openCreate() {
    setEditing(null);
    setFormOpen(true);
  }

  function confirmDelete() {
    if (!deleting) return;
    const snapshot = deleting;
    dispatch({ type: 'note:delete', id: snapshot.id });
    setDeleting(null);
    show('Catatan dihapus.', {
      action: {
        label: 'Urungkan',
        onClick: () => dispatch({ type: 'note:add', note: snapshot }),
      },
      duration: 5000,
    });
  }

  return (
    <div className="flex flex-col gap-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-micro uppercase text-fg-lo">Catatan</p>
          <h1 className="text-h1 text-fg-hi">Peta pengetahuanmu.</h1>
        </div>
        <Button onClick={openCreate} icon={<Plus className="h-4 w-4" strokeWidth={2} />}>
          Catatan
        </Button>
      </header>

      <SearchInput value={query} onChange={setQuery} placeholder="Cari catatan…" />

      {filtered.length === 0 ? (
        <EmptyState
          icon={<FileText className="h-10 w-10" strokeWidth={1.5} />}
          title={query ? 'Tidak ada catatan cocok.' : 'Belum ada catatan.'}
          description={query ? 'Coba kata kunci lain.' : 'Tulis yang pertama.'}
          action={!query ? <Button onClick={openCreate}>Catatan baru</Button> : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => { setEditing(n); setFormOpen(true); }}
              className="flex flex-col rounded-card border border-line bg-surface-2 p-4 text-left transition-colors hover:border-line-strong"
            >
              <div className={`mb-2 h-1 w-8 rounded-full ${colorBar(n.color)}`} />
              <div className="flex items-start justify-between gap-2">
                <p className="line-clamp-2 flex-1 text-h2 text-fg-hi">{n.title || 'Tanpa judul'}</p>
                {n.pinned && <Pin className="h-4 w-4 shrink-0 text-accent-500" strokeWidth={2} fill="currentColor" />}
              </div>
              <p className="mt-1 line-clamp-3 text-caption text-fg-mid">
                {n.content.slice(0, 140) || 'Kosong.'}
              </p>
              <p className="mt-3 text-caption text-fg-dim">{formatRelative(new Date(n.updated_at))}</p>
            </button>
          ))}
        </div>
      )}

      <NoteForm
        open={formOpen}
        onClose={() => { setFormOpen(false); setEditing(null); }}
        initial={editing}
        onDelete={(n) => { setFormOpen(false); setEditing(null); setDeleting(n); }}
      />

      <ConfirmDialog
        open={deleting !== null}
        title="Hapus catatan ini?"
        description={deleting ? `"${deleting.title || 'Tanpa judul'}" akan dihapus.` : ''}
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}

function NoteForm({
  open, onClose, initial, onDelete,
}: {
  open: boolean;
  onClose: () => void;
  initial: Note | null;
  onDelete: (n: Note) => void;
}) {
  const dispatch = useDispatch();
  const { show } = useToast();
  const [title, setTitle] = useState(initial?.title ?? '');
  const [content, setContent] = useState(initial?.content ?? '');
  const [color, setColor] = useState(initial?.color ?? 'accent');
  const [tagsInput, setTagsInput] = useState((initial?.tags ?? []).join(', '));
  const [pinned, setPinned] = useState(initial?.pinned ?? false);

  function submit() {
    if (!title.trim() && !content.trim()) {
      show('Catatan kosong tidak disimpan.');
      return;
    }
    const tags = tagsInput.split(',').map((s) => s.trim()).filter(Boolean);
    const now = new Date().toISOString();
    const payload: Note = {
      id: initial?.id ?? uid(),
      title: title.trim(),
      content,
      color,
      tags: tags.length > 0 ? tags : undefined,
      pinned,
      created_at: initial?.created_at ?? now,
      updated_at: now,
    };
    if (initial) {
      dispatch({ type: 'note:update', id: initial.id, patch: payload });
      show('Catatan diperbarui.');
    } else {
      dispatch({ type: 'note:add', note: payload });
      show('Catatan tersimpan.');
    }
    onClose();
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={initial ? 'Ubah catatan' : 'Catatan baru'}
      footer={
        <div className="flex justify-between gap-2">
          {initial ? (
            <Button variant="ghost" onClick={() => onDelete(initial)} icon={<Trash2 className="h-4 w-4" strokeWidth={2} />}>
              Hapus
            </Button>
          ) : <span />}
          <div className="flex gap-2">
            <Button variant="ghost" onClick={onClose}>Batal</Button>
            <Button onClick={submit}>{initial ? 'Simpan' : 'Tambah'}</Button>
          </div>
        </div>
      }
    >
      <div className="flex flex-col gap-3">
        <Input
          label="Judul"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          autoFocus
        />
        <Textarea
          label="Isi"
          rows={10}
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />
        <div>
          <p className="mb-1.5 text-label text-fg-mid">Warna</p>
          <div className="flex flex-wrap gap-2">
            {NOTE_COLORS.map((c) => (
              <button
                key={c.key}
                type="button"
                onClick={() => setColor(c.key)}
                className={`h-8 w-8 rounded-full ${c.bar} ${color === c.key ? 'ring-2 ring-offset-2 ring-offset-surface-3 ring-fg-hi' : ''}`}
                aria-label={c.label}
              />
            ))}
          </div>
        </div>
        <Input
          label="Tag (pisahkan dengan koma)"
          value={tagsInput}
          onChange={(e) => setTagsInput(e.target.value)}
          placeholder="belajar, js, penting"
        />
        <div>
          <p className="mb-1.5 text-label text-fg-mid">Sematkan di atas</p>
          <button
            type="button"
            onClick={() => setPinned((p) => !p)}
            className={`inline-flex items-center gap-2 rounded-button border px-3 py-1.5 text-caption ${pinned ? 'border-accent-500 bg-accent-500 text-white' : 'border-line bg-surface-2 text-fg-mid'}`}
          >
            <Pin className="h-3.5 w-3.5" strokeWidth={2} />
            {pinned ? 'Tersemat' : 'Sematkan'}
          </button>
        </div>
      </div>
    </BottomSheet>
  );
}