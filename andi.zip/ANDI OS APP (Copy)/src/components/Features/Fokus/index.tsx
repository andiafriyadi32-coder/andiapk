import { useEffect, useMemo, useRef, useState } from 'react';
import { Pause, Play, RotateCcw, SkipForward, Timer } from 'lucide-react';

import { useAppState, useDispatch } from '../../lib/store';
import type { PomodoroType } from '../../lib/types';
import { formatNumber, uid } from '../../lib/format';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { RingProgress } from '../../components/ui/RingProgress';
import { useToast } from '../../components/ui/Toast';

type Mode = 'focus' | 'short_break' | 'long_break';

const MODE_LABEL: Record<Mode, string> = {
  focus: 'Fokus',
  short_break: 'Istirahat pendek',
  long_break: 'Istirahat panjang',
};

export default function Fokus(): JSX.Element {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const settings = state.settings.pomodoro;

  const [mode, setMode] = useState<Mode>('focus');
  const [running, setRunning] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(settings.focus * 60);
  const [focusCount, setFocusCount] = useState(0);
  const justFinishedRef = useRef(false);

  const totalSeconds = useMemo(() => {
    if (mode === 'focus') return settings.focus * 60;
    if (mode === 'short_break') return settings.short * 60;
    return settings.long * 60;
  }, [mode, settings]);

  const pct = totalSeconds > 0 ? (totalSeconds - secondsLeft) / totalSeconds : 0;

  // Interval tick
  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => {
      setSecondsLeft((s) => Math.max(0, s - 1));
    }, 1000);
    return () => window.clearInterval(id);
  }, [running]);

  // Finish handler
  useEffect(() => {
    if (!running) return;
    if (secondsLeft > 0) return;
    if (justFinishedRef.current) return;
    justFinishedRef.current = true;
    setRunning(false);

    // Log session
    const session: {
      id: string;
      started_at: string;
      type: PomodoroType;
      duration_min: number;
      completed: boolean;
    } = {
      id: uid(),
      started_at: new Date(Date.now() - totalSeconds * 1000).toISOString(),
      type: mode === 'focus' ? 'focus' : mode === 'short_break' ? 'short_break' : 'long_break',
      duration_min: Math.round(totalSeconds / 60),
      completed: true,
    };
    dispatch({ type: 'pomodoro:add', session });

    if ('vibrate' in navigator && typeof navigator.vibrate === 'function') {
      navigator.vibrate([200, 100, 200]);
    }
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification('Sesi selesai', {
          body: `${MODE_LABEL[mode]} ${Math.round(totalSeconds / 60)} menit selesai.`,
        });
      } catch {
        /* diabaikan */
      }
    }

    if (mode === 'focus') {
      const nextCount = focusCount + 1;
      setFocusCount(nextCount);
      const nextMode: Mode = nextCount % settings.long_break_interval === 0 ? 'long_break' : 'short_break';
      show(`${MODE_LABEL[mode]} selesai. Waktunya ${MODE_LABEL[nextMode].toLowerCase()}.`);
      setMode(nextMode);
      setSecondsLeft(nextMode === 'long_break' ? settings.long * 60 : settings.short * 60);
    } else {
      show('Istirahat selesai. Siap fokus lagi?');
      setMode('focus');
      setSecondsLeft(settings.focus * 60);
    }
    justFinishedRef.current = false;
  }, [secondsLeft, running, mode, totalSeconds, focusCount, settings, dispatch, show]);

  function start() {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => undefined);
    }
    setRunning(true);
  }

  function pause() {
    setRunning(false);
  }

  function reset() {
    setRunning(false);
    setSecondsLeft(totalSeconds);
  }

  function skip() {
    setRunning(false);
    if (mode === 'focus') {
      setMode('short_break');
      setSecondsLeft(settings.short * 60);
    } else {
      setMode('focus');
      setSecondsLeft(settings.focus * 60);
    }
  }

  const sessionsToday = useMemo(() => {
    const todayKey = new Date().toDateString();
    return state.pomodoro_sessions.filter(
      (s) => new Date(s.started_at).toDateString() === todayKey && s.type === 'focus' && s.completed
    ).length;
  }, [state.pomodoro_sessions]);

  return (
    <div className="flex flex-col gap-4">
      <header>
        <p className="text-micro uppercase text-fg-lo">Fokus</p>
        <h1 className="text-h1 text-fg-hi">Sesi fokus dan istirahat.</h1>
      </header>

      <Card>
        <div className="flex flex-col items-center gap-4 py-4">
          <p className="text-micro uppercase text-fg-lo">{MODE_LABEL[mode]}</p>
          <RingProgress value={pct} size={200} strokeWidth={10} tone={mode === 'focus' ? 'accent' : 'success'}>
            <div className="flex flex-col items-center">
              <span className="num text-timer-num text-fg-hi">{formatTime(secondsLeft)}</span>
              <span className="mt-1 text-caption text-fg-lo">dari {Math.round(totalSeconds / 60)} menit</span>
            </div>
          </RingProgress>

          <div className="flex items-center gap-2">
            {running ? (
              <Button variant="secondary" onClick={pause} icon={<Pause className="h-4 w-4" strokeWidth={2} />}>
                Jeda
              </Button>
            ) : (
              <Button onClick={start} icon={<Play className="h-4 w-4" strokeWidth={2} />}>
                Mulai
              </Button>
            )}
            <Button variant="ghost" onClick={reset} icon={<RotateCcw className="h-4 w-4" strokeWidth={2} />}>
              Reset
            </Button>
            <Button variant="ghost" onClick={skip} icon={<SkipForward className="h-4 w-4" strokeWidth={2} />}>
              Lewati
            </Button>
          </div>

          <p className="text-caption text-fg-lo">
            Fokus hari ini: <span className="num text-fg-hi">{sessionsToday}</span> sesi
          </p>
        </div>
      </Card>

      <Card>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-button bg-accent-50 text-accent-500">
            <Timer className="h-5 w-5" strokeWidth={1.75} />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-label text-fg-hi">Siklus</p>
            <p className="text-caption text-fg-lo">
              {settings.focus}m fokus · {settings.short}m pendek · {settings.long}m panjang setiap {settings.long_break_interval} sesi.
            </p>
          </div>
        </div>
        <div className="mt-3 flex justify-center gap-1">
          {Array.from({ length: settings.long_break_interval }).map((_, i) => {
            const active = i < focusCount % settings.long_break_interval;
            return (
              <span
                key={i}
                className={`h-2 w-8 rounded-full ${active ? 'bg-accent-500' : 'bg-surface-4'}`}
                aria-label={active ? 'Sesi selesai' : 'Sesi belum selesai'}
              />
            );
          })}
        </div>
        <p className="mt-2 text-center text-caption text-fg-dim">
          {formatNumber(state.pomodoro_sessions.filter((s) => s.completed && s.type === 'focus').length)} sesi fokus total
        </p>
      </Card>
    </div>
  );
}

function formatTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}