import { useRef, useState } from 'react';
import { Download, RotateCcw, Upload } from 'lucide-react';

import { useAppState, useDispatch, useStore } from '../../lib/store';
import {
  CORE_MODULES, MODULE_LABELS, OPTIONAL_MODULES, type ModuleId,
} from '../../lib/types';
import { formatNumber } from '../../lib/format';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { SegmentedControl, type SegmentedOption } from '../../components/ui/SegmentedControl';
import { Toggle } from '../../components/ui/Toggle';
import { Card } from '../../components/ui/Card';
import { Avatar } from '../../components/ui/Avatar';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';

const THEME_OPTIONS: SegmentedOption<'dark' | 'light'>[] = [
  { value: 'dark', label: 'Gelap' },
  { value: 'light', label: 'Terang' },
];

const STORAGE_KEY = 'andi-os-v1';

export default function Pengaturan(): JSX.Element {
  const state = useAppState();
  const dispatch = useDispatch();
  const store = useStore();
  const { show } = useToast();
  const [nama, setNama] = useState(state.settings.nama);
  const [resetOpen, setResetOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  function saveName() {
    if (nama.trim() && nama.trim() !== state.settings.nama) {
      dispatch({ type: 'settings:update', patch: { nama: nama.trim() } });
      show('Nama diperbarui.');
    }
  }

  function toggleModule(id: ModuleId, on: boolean) {
    const next = on
      ? Array.from(new Set([...state.settings.active_modules, id]))
      : state.settings.active_modules.filter((x) => x !== id);
    dispatch({ type: 'settings:update', patch: { active_modules: next } });
  }

  function exportJson() {
    try {
      const data = JSON.stringify(state, null, 2);
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `andi-os-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      show('Backup diunduh.');
    } catch {
      show('Gagal mengekspor data.');
    }
  }

  function importJson(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = String(reader.result ?? '');
        const parsed = JSON.parse(text) as { version?: number };
        if (parsed.version !== 1) {
          show('File bukan backup ANDI OS versi ini.');
          return;
        }
        localStorage.setItem(STORAGE_KEY, text);
        show('Data diimpor. Memuat ulang…');
        setTimeout(() => window.location.reload(), 600);
      } catch {
        show('File tidak valid.');
      }
    };
    reader.readAsText(file);
  }

  function doReset() {
    try {
      localStorage.removeItem(STORAGE_KEY);
      show('Data dihapus. Memuat ulang…');
      setTimeout(() => window.location.reload(), 600);
    } catch {
      show('Gagal menghapus data.');
    }
  }

  const storageBytes = useMemoStorageSize(state);

  return (
    <div className="flex flex-col gap-4">
      <header>
        <p className="text-micro uppercase text-fg-lo">Pengaturan</p>
        <h1 className="text-h1 text-fg-hi">Kendali penuh atas datamu.</h1>
      </header>

      <Card>
        <p className="mb-3 text-micro uppercase text-fg-lo">Profil</p>
        <div className="flex items-center gap-3">
          <Avatar name={state.settings.nama} size={48} />
          <div className="min-w-0 flex-1">
            <Input
              value={nama}
              onChange={(e) => setNama(e.target.value)}
              onBlur={saveName}
              placeholder="Nama panggilan"
            />
          </div>
        </div>
      </Card>

      <Card>
        <p className="mb-3 text-micro uppercase text-fg-lo">Tampilan</p>
        <SegmentedControl
          options={THEME_OPTIONS}
          value={state.settings.theme}
          onChange={(t) => dispatch({ type: 'settings:update', patch: { theme: t } })}
          fullWidth
        />
      </Card>

      <Card>
        <p className="mb-1 text-micro uppercase text-fg-lo">Modul inti</p>
        <p className="mb-3 text-caption text-fg-lo">Selalu aktif.</p>
        <ul className="flex flex-col gap-2">
          {CORE_MODULES.map((m) => (
            <li key={m} className="flex items-center justify-between gap-2 text-body text-fg-mid">
              <span>{MODULE_LABELS[m]}</span>
              <span className="rounded-chip bg-success/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-success">Aktif</span>
            </li>
          ))}
        </ul>
      </Card>

      <Card>
        <p className="mb-1 text-micro uppercase text-fg-lo">Modul tambahan</p>
        <p className="mb-3 text-caption text-fg-lo">Aktifkan yang kamu butuhkan. Data tetap tersimpan saat dimatikan.</p>
        <ul className="flex flex-col gap-3">
          {OPTIONAL_MODULES.map((m) => (
            <li key={m} className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-body text-fg-hi">{MODULE_LABELS[m]}</p>
              </div>
              <Toggle
                checked={state.settings.active_modules.includes(m)}
                onChange={(on) => toggleModule(m, on)}
              />
            </li>
          ))}
        </ul>
      </Card>

      <Card>
        <p className="mb-3 text-micro uppercase text-fg-lo">Data</p>
        <p className="mb-3 text-caption text-fg-lo">
          Ukuran tersimpan: <span className="num">{formatNumber(Math.round(storageBytes / 1024))} KB</span>
        </p>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={exportJson} icon={<Download className="h-4 w-4" strokeWidth={2} />}>
            Ekspor JSON
          </Button>
          <Button
            variant="secondary"
            onClick={() => fileRef.current?.click()}
            icon={<Upload className="h-4 w-4" strokeWidth={2} />}
          >
            Impor JSON
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) importJson(f);
              e.target.value = '';
            }}
          />
          <Button
            variant="danger"
            onClick={() => setResetOpen(true)}
            icon={<RotateCcw className="h-4 w-4" strokeWidth={2} />}
          >
            Reset semua
          </Button>
        </div>
      </Card>

      <Card>
        <p className="mb-2 text-micro uppercase text-fg-lo">Tentang</p>
        <p className="text-body text-fg-hi">ANDI OS · v0.1.0</p>
        <p className="mt-1 text-caption text-fg-lo">
          Aplikasi offline. Data hanya di perangkat ini.
        </p>
        <p className="mt-1 text-caption text-fg-lo">
          Modul aktif saat ini: <span className="num">{store.state.settings.active_modules.length}</span>
        </p>
      </Card>

      <ConfirmDialog
        open={resetOpen}
        title="Hapus semua data?"
        description="Seluruh transaksi, tugas, catatan, dan riwayat akan hilang. Ekspor dulu jika perlu."
        confirmLabel="Hapus semua"
        onConfirm={doReset}
        onCancel={() => setResetOpen(false)}
      />
    </div>
  );
}

function useMemoStorageSize(state: unknown): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return raw.length;
    return JSON.stringify(state).length;
  } catch {
    return 0;
  }
}