import { useMemo, useState } from 'react';
import { BookOpen, Plus, Star, Trash2 } from 'lucide-react';

import { useAppState, useDispatch } from '../../lib/store';
import type { Journal, Mood } from '../../lib/types';
import { formatDateShort, formatRelative, toDateStr, todayStr, uid } from '../../lib/format';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Textarea } from '../../components/ui/Textarea';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';

const MOOD_LABELS: Record<Mood, string> = {
  1: 'Sangat berat',
  2: 'Berat',
  3: 'Biasa',
  4: 'Baik',
  5: 'Sangat baik',
};

export default function Jurnal(): JSX.Element {
  const state = useAppState();
  const dispatch = useDispatch();
  const { show } = useToast();
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Journal | null>(null);
  const [deleting, setDeleting] = useState<Journal | null>(null);

  const sorted = useMemo(
    () => [...state.journal].sort((a, b) => b.date.localeCompare(a.date) || b.created_at.localeCompare(a.created_at)),
    [state.journal]
  );

  const onThisDay = useMemo(() => {
    const todayStr_ = todayStr();
    const targets = ['1y', '6m', '1m'] as const;
    const out: { label: string; entry: Journal }[] = [];
    for (const key of targets) {
      const target = offsetDate(todayStr_, key);
      const match = state.journal.find((j) => j.date === target);
      if (match) {
        out.push({
          label: key === '1y' ? '1 tahun lalu' : key === '6m' ? '6 bulan lalu' : '1 bulan lalu',
          entry: match,
        });
      }
    }
    return out;
  }, [state.journal]);

  function openCreate() {
    setEditing(null);
    setFormOpen(true);
  }

  function confirmDelete() {
    if (!deleting) return;
    const snapshot = deleting;
    dispatch({ type: 'journal:delete', id: snapshot.id });
    setDeleting(null);
    show('Jurnal dihapus.', {
      action: {
        label: 'Urungkan',
        onClick: () => dispatch({ type: 'journal:add', journal: snapshot }),
      },
      duration: 5000,
    });
  }

  return (
    <div className="flex flex-col gap-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-micro uppercase text-fg-lo">Jurnal</p>
          <h1 className="text-h1 text-fg-hi">Ceritakan harimu.</h1>
        </div>
        <Button onClick={openCreate} icon={<Plus className="h-4 w-4" strokeWidth={2} />}>
          Jurnal
        </Button>
      </header>

      {onThisDay.length > 0 && (
        <Card>
          <p className="mb-2 text-micro uppercase text-fg-lo">On this day</p>
          <ul className="flex flex-col gap-2">
            {onThisDay.map(({ label, entry }) => (
              <li key={label}>
                <button
                  type="button"
                  onClick={() => { setEditing(entry); setFormOpen(true); }}
                  className="flex w-full items-start gap-2 rounded-card-sm border border-line bg-surface-2 px-3 py-2 text-left hover:border-line-strong"
                >
                  <Star className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent-500" strokeWidth={2} fill="currentColor" />
                  <div className="min-w-0 flex-1">
                    <p className="text-caption text-fg-lo">{label}</p>
                    <p className="truncate text-body text-fg-hi">{entry.title || 'Tanpa judul'}</p>
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {sorted.length === 0 ? (
        <EmptyState
          icon={<BookOpen className="h-10 w-10" strokeWidth={1.5} />}
          title="Belum ada jurnal."
          description="Ceritakan harimu, sekecil apa pun."
          action={<Button onClick={openCreate}>Tulis jurnal</Button>}
        />
      ) : (
        <ul className="flex flex-col gap-2">
          {sorted.map((j) => (
            <li key={j.id}>
              <Card padded={false}>
                <button
                  type="button"
                  onClick={() => { setEditing(j); setFormOpen(true); }}
                  className="w-full p-4 text-left"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-caption text-fg-lo">{formatDateShort(new Date(j.date))}</p>
                    <div className="flex items-center gap-0.5">
                      {[1, 2, 3, 4, 5].map((m) => (
                        <Star
                          key={m}
                          className={`h-3 w-3 ${m <= j.mood ? 'text-warning' : 'text-fg-dim'}`}
                          strokeWidth={2}
                          fill={m <= j.mood ? 'currentColor' : 'none'}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="mt-1 truncate text-h2 text-fg-hi">{j.title || 'Tanpa judul'}</p>
                  {j.gratitude && (
                    <p className="mt-1 line-clamp-1 text-caption italic text-fg-mid">
                      "{j.gratitude}"
                    </p>
                  )}
                  <p className="mt-2 line-clamp-2 text-caption text-fg-mid">{j.content || 'Kosong.'}</p>
                  <p className="mt-2 text-caption text-fg-dim">{formatRelative(new Date(j.updated_at))}</p>
                </button>
              </Card>
            </li>
          ))}
        </ul>
      )}

      <JournalForm
        open={formOpen}
        onClose={() => { setFormOpen(false); setEditing(null); }}
        initial={editing}
        onDelete={(j) => { setFormOpen(false); setEditing(null); setDeleting(j); }}
      />

      <ConfirmDialog
        open={deleting !== null}
        title="Hapus jurnal ini?"
        description={deleting ? `"${deleting.title || 'Tanpa judul'}" akan dihapus.` : ''}
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}

function offsetDate(base: string, key: '1y' | '6m' | '1m'): string {
  const [y, m, d] = base.split('-').map(Number);
  const date = new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1);
  if (key === '1y') date.setFullYear(date.getFullYear() - 1);
  else if (key === '6m') date.setMonth(date.getMonth() - 6);
  else date.setMonth(date.getMonth() - 1);
  return toDateStr(date);
}

function JournalForm({
  open, onClose, initial, onDelete,
}: {
  open: boolean;
  onClose: () => void;
  initial: Journal | null;
  onDelete: (j: Journal) => void;
}) {
  const dispatch = useDispatch();
  const { show } = useToast();
  const [title, setTitle] = useState(initial?.title ?? '');
  const [date, setDate] = useState(initial?.date ?? todayStr());
  const [mood, setMood] = useState<Mood>(initial?.mood ?? 3);
  const [gratitude, setGratitude] = useState(initial?.gratitude ?? '');
  const [content, setContent] = useState(initial?.content ?? '');

  function submit() {
    if (!title.trim() && !content.trim()) {
      show('Jurnal kosong tidak disimpan.');
      return;
    }
    const now = new Date().toISOString();
    const payload: Journal = {
      id: initial?.id ?? uid(),
      title: title.trim(),
      content,
      date,
      mood,
      gratitude: gratitude.trim() || undefined,
      created_at: initial?.created_at ?? now,
      updated_at: now,
    };
    if (initial) {
      dispatch({ type: 'journal:update', id: initial.id, patch: payload });
      show('Jurnal diperbarui.');
    } else {
      dispatch({ type: 'journal:add', journal: payload });
      show('Jurnal tersimpan.');
    }
    onClose();
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={initial ? 'Ubah jurnal' : 'Jurnal baru'}
      footer={
        <div className="flex justify-between gap-2">
          {initial ? (
            <Button variant="ghost" onClick={() => onDelete(initial)} icon={<Trash2 className="h-4 w-4" strokeWidth={2} />}>
              Hapus
            </Button>
          ) : <span />}
          <div className="flex gap-2">
            <Button variant="ghost" onClick={onClose}>Batal</Button>
            <Button onClick={submit}>{initial ? 'Simpan' : 'Tulis'}</Button>
          </div>
        </div>
      }
    >
      <div className="flex flex-col gap-3">
        <Input
          label="Tanggal"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <div>
          <p className="mb-1.5 text-label text-fg-mid">Suasana hati</p>
          <div className="flex items-center gap-1">
            {([1, 2, 3, 4, 5] as Mood[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMood(m)}
                aria-label={MOOD_LABELS[m]}
                className="rounded-button p-1.5 transition-transform active:scale-95"
              >
                <Star
                  className={`h-6 w-6 ${m <= mood ? 'text-warning' : 'text-fg-dim'}`}
                  strokeWidth={2}
                  fill={m <= mood ? 'currentColor' : 'none'}
                />
              </button>
            ))}
            <span className="ml-2 text-caption text-fg-lo">{MOOD_LABELS[mood]}</span>
          </div>
        </div>
        <Input
          label="Judul"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <Input
          label="Ucapan syukur"
          value={gratitude}
          onChange={(e) => setGratitude(e.target.value)}
          placeholder="Apa yang disyukuri hari ini?"
        />
        <Textarea
          label="Isi jurnal"
          rows={8}
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />
      </div>
    </BottomSheet>
  );
}