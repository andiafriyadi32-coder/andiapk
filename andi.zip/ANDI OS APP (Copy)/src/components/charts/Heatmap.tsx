export interface HeatmapDay {
  date: string;
  value: number;
}

export interface HeatmapProps {
  days: HeatmapDay[];
  weeks?: number;
  maxValue?: number;
  cellSize?: number;
}

export function Heatmap({
  days,
  weeks = 13,
  maxValue = 1,
  cellSize = 12,
}: HeatmapProps) {
  const cells = days.slice(-weeks * 7);
  const colorFor = (v: number): string => {
    if (v <= 0) return 'var(--surface-4)';
    const t = Math.min(1, v / Math.max(1, maxValue));
    if (t < 0.34) return 'var(--accent-100)';
    if (t < 0.67) return 'var(--accent-300)';
    return 'var(--accent-500)';
  };
  return (
    <div
      className="grid grid-flow-col grid-rows-7 gap-1"
      role="img"
      aria-label="Peta panas aktivitas"
    >
      {cells.map((d, i) => (
        <div
          key={`${d.date}-${i}`}
          className="rounded-sm"
          style={{
            width: cellSize,
            height: cellSize,
            backgroundColor: colorFor(d.value),
          }}
          title={`${d.date}: ${d.value}`}
        />
      ))}
    </div>
  );
}