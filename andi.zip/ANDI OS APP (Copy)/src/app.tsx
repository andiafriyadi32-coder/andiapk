import { StoreProvider } from './lib/store';
import { AppShell } from './components/layout/AppShell';

export default function App(): JSX.Element {
  return (
    <StoreProvider>
      <AppShell />
    </StoreProvider>
  );
}